#include <pthread.h>
#include <stdio.h>

#define N 10000
#define K 4

int arr[N];

struct Range {
    int start;
    int end;
    long long sum;
};

void* sum_worker(void* arg) {
    struct Range* range = (struct Range*)arg;

    range->sum = 0;
    for (int i = range->start; i < range->end; ++i) {
        range->sum += arr[i];
    }

    return NULL;
}

int main(void) {
    pthread_t tids[K];
    struct Range ranges[K];
    int step = N / K;
    long long total = 0;

    for (int i = 0; i < N; ++i) {
        arr[i] = i;
    }

    for (int i = 0; i < K; ++i) {
        ranges[i].start = i * step;
        ranges[i].end = (i == K - 1) ? N : (i + 1) * step;
        pthread_create(&tids[i], NULL, sum_worker, &ranges[i]);
    }

    for (int i = 0; i < K; ++i) {
        pthread_join(tids[i], NULL);
        total += ranges[i].sum;
    }

    printf("最后总和: %lld\n", total);
    return 0;
}

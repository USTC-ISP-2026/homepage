#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// 演示死锁的两个互斥锁
pthread_mutex_t m1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t m2 = PTHREAD_MUTEX_INITIALIZER;

void* worker_a(void* arg) {
    printf("Worker A: 试图获取锁 m1...\n");
    pthread_mutex_lock(&m1);
    printf("Worker A: 成功获取锁 m1，正在执行操作 (sleep 1)...\n");
    
    sleep(1);
    
    printf("Worker A: 试图获取锁 m2...\n");
    // 这里会永久阻塞，因为 m2 被 Worker B 拿着
    pthread_mutex_lock(&m2);
    printf("Worker A: 成功获取锁 m2！（这句话永远不会打印）\n");
    
    pthread_mutex_unlock(&m2);
    pthread_mutex_unlock(&m1);
    return NULL;
}

void* worker_b(void* arg) {
    printf("Worker B: 试图获取锁 m2...\n");
    pthread_mutex_lock(&m2);
    printf("Worker B: 成功获取锁 m2，正在执行操作 (sleep 1)...\n");
    
    sleep(1);
    
    printf("Worker B: 试图获取锁 m1...\n");
    // 这里会永久阻塞，因为 m1 被 Worker A 拿着
    pthread_mutex_lock(&m1);
    printf("Worker B: 成功获取锁 m1！（这句话永远不会打印）\n");
    
    pthread_mutex_unlock(&m1);
    pthread_mutex_unlock(&m2);
    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    
    printf("Main: 开始运行，演示死锁现象（程序会永远卡住）\n");
    printf("--------------------------------------------------\n");
    
    // 同时创建两个线程
    pthread_create(&t1, NULL, worker_a, NULL);
    pthread_create(&t2, NULL, worker_b, NULL);
    
    // 等待线程退出（主线程同样会因为子线程死锁而被带走，永远等不到汇合点）
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    
    printf("Main: 线程执行完毕 (如果看到这条输出，说明没有发生死锁)\n");
    return 0;
}

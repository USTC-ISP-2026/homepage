#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

int ready = 0; // 全局标志，用于由于原始的共享通信

void* worker(void* arg) {
    printf("worker: 等待主线程发来信号...\n");
    /* 一直死循环检查，白白消耗CPU (忙等待 Busy Wait) */
    while (ready == 0) {
        // 里面什么都不做，一直死循环空转
    }
    printf("worker: 收到信号！工作线程开始执行后续任务。\n");
    return NULL;
}

int main(void) {
    pthread_t tid;
    
    // 创建工作线程
    pthread_create(&tid, NULL, worker, NULL);
    
    // 主线程模拟做一些耗时的准备工作
    for (int i = 0; i < 3; i++) {
        printf("main: 准备中... sleep %d 秒\n", i + 1);
        sleep(1);
    }
    
    // 准备完毕，发出信号
    printf("main: 准备完毕，将 ready 设为 1\n");
    ready = 1;
    
    // 等待工作线程退出
    pthread_join(tid, NULL);
    
    return 0;
}

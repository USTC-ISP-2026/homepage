#include <pthread.h>
#include <stdio.h>

int counter = 0;
// 使用宏进行互斥锁的静态初始化
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* add_one_safe(void* arg) {
    int loops = *(int*)arg;
    for (int i = 0; i < loops; ++i) {
        // 加锁：同一时刻只允许一个线程进入关键区
        pthread_mutex_lock(&mutex);
        
        counter++;
        
        // 解锁：操作完毕，释放占用
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    int loops = 100000;
    
    // 创建两个线程同时累加
    pthread_create(&t1, NULL, add_one_safe, &loops);
    pthread_create(&t2, NULL, add_one_safe, &loops);
    
    // 等待线程执行完毕
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    
    // 输出期望应该稳稳达到 200000，不会发生竞态遮盖
    printf("counter = %d\n", counter);
    
    // 我们用的是静态初始化宏，所以此处不需要手工调用 pthread_mutex_destroy
    return 0;
}

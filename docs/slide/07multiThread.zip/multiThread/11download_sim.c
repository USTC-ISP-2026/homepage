#include <pthread.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>

struct Task {
    char name[16];
    int cost;
};

void* download(void* arg) {
    struct Task* task = (struct Task*)arg;

    sleep(task->cost);
    printf("完成下载：%s\n", task->name);

    return NULL;
}

int main(void) {
    struct Task tasks[3] = {{"A", 2}, {"B", 1}, {"C", 3}};
    time_t start;
    pthread_t tids[3];

    start = time(NULL);
    for (int i = 0; i < 3; ++i) {
        download(&tasks[i]);
    }
    printf("串行总耗时：%ld\n\n", time(NULL) - start);

    start = time(NULL);
    for (int i = 0; i < 3; ++i) {
        pthread_create(&tids[i], NULL, download, &tasks[i]);
    }
    for (int i = 0; i < 3; ++i) {
        pthread_join(tids[i], NULL);
    }
    printf("并发总耗时：%ld\n", time(NULL) - start);

    return 0;
}

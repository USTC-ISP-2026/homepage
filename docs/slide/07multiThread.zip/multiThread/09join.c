#include <pthread.h>
#include <stdio.h>

void* worker(void* arg) {
    (void)arg;
    printf("worker: start\n");
    printf("worker: finish\n");
    return NULL;
}

int main(void) {
    pthread_t tid;

    pthread_create(&tid, NULL, worker, NULL);

    printf("main: before join\n");
    pthread_join(tid, NULL);
    printf("main: after join\n");

    return 0;
}

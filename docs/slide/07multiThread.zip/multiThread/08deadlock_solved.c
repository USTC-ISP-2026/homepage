#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// 两把独立的互斥锁
pthread_mutex_t m1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t m2 = PTHREAD_MUTEX_INITIALIZER;

void* worker_a(void* arg) {
    printf("Worker A: 试图获取锁 m1...\n");
    pthread_mutex_lock(&m1);
    printf("Worker A: 成功获取锁 m1，正在执行操作 (sleep 1)...\n");
    
    sleep(1);
    
    printf("Worker A: 试图获取锁 m2...\n");
    pthread_mutex_lock(&m2);
    printf("Worker A: 成功获取锁 m2！此时两把锁均已拿到，开始做核心业务。\n");
    
    // 用毕解锁，注意顺序与加锁相反
    pthread_mutex_unlock(&m2);
    pthread_mutex_unlock(&m1);
    return NULL;
}

void* worker_b(void* arg) {
    printf("Worker B: 规避死锁，我也老老实实先试图获取锁 m1...\n");
    // 与 A 统一加锁顺序！如果 A 正在用 m1，B 会在这里乖乖排队，而不是去抢 m2
    pthread_mutex_lock(&m1);  
    printf("Worker B: 成功获取锁 m1，正在执行操作 (sleep 1)...\n");
    
    sleep(1);
    
    printf("Worker B: 试图获取锁 m2...\n");
    pthread_mutex_lock(&m2);
    printf("Worker B: 成功获取锁 m2！此时两把锁均已拿到，开始做核心业务。\n");
    
    // 用毕解锁，注意顺序与加锁相反
    pthread_mutex_unlock(&m2);
    pthread_mutex_unlock(&m1);
    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    
    printf("Main: 开始运行，演示解除死锁（统一加锁顺序）\n");
    printf("--------------------------------------------------\n");
    
    // 同时创建两个线程
    pthread_create(&t1, NULL, worker_a, NULL);
    pthread_create(&t2, NULL, worker_b, NULL);
    
    // 等待线程退出
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    
    printf("--------------------------------------------------\n");
    printf("Main: 线程巧妙避开死锁，全部成功执行完毕，安全退出程序！\n");
    return 0;
}

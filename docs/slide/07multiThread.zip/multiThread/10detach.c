#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void* worker(void* arg) {
    (void)arg;
    printf("worker: running\n");
    sleep(1);
    printf("worker: finish\n");
    return NULL;
}

int main(void) {
    pthread_t tid;

    pthread_create(&tid, NULL, worker, NULL);
    pthread_detach(tid);

    printf("main: detached\n");
    pthread_exit(NULL);
}

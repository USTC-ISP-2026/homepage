#include <pthread.h>
#include <stdio.h>

int counter = 0;

void* add_one(void* arg) {
    int loops = *(int*)arg;
    for (int i = 0; i < loops; ++i) {
        int tmp = counter;
        tmp = tmp + 1;
        counter = tmp;
    }
    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    int loops = 100000;
    
    pthread_create(&t1, NULL, add_one, &loops);
    pthread_create(&t2, NULL, add_one, &loops);
    
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    
    printf("counter=%d\n", counter);
    
    return 0;
}

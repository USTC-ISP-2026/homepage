#include <stdio.h>
#include <pthread.h>
#include <unistd.h>  // for sleep()


void* thread_func(void* arg) 
{
    // 子线程执行的函数
    int id = *(int*)arg;
    printf("Worker %d: Hello!\n", id);
    pthread_exit(NULL); // 子线程主动退出
}

int main() 
{
    pthread_t t1;
    int arg1 = 1;
    
    // 创建一个子线程
    pthread_create(&t1, NULL, thread_func, &arg1);
    
    printf("Main thread: waiting...\n");
    //sleep(1);
    pthread_exit(NULL); // 主线程退出，系统等剩余线程结束后才终止进程
}

